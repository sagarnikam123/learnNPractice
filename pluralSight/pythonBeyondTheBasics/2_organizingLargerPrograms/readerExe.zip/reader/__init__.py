from reader.reader import Reader
print("reader is being imported!")
